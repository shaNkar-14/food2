package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.table;

import jakarta.persistence.GenerationType;

@Entity
@Table(name= "users")

public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String email;
	private String firstname;
	private String lastname;
	
	

}
